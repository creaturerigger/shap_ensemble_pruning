# src/trainer/trainer.py

from src.trainer.CNN import CustomCNN
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm
import os
import numpy as np

class Trainer:
    def __init__(self, train_dataloader: DataLoader, test_dataloader: DataLoader,
                 artefact_dir: str, device='cuda' if torch.cuda.is_available() else 'cpu') -> None:
        if not isinstance(train_dataloader, DataLoader) or not isinstance(test_dataloader, DataLoader):
            raise ValueError("`train_dataloader` and `test_dataloader` arguments must be of type `torch.utils.data.DataLoader`.")
        self.train_dataloader: DataLoader = train_dataloader
        self.test_dataloader: DataLoader = test_dataloader
        self.device = device
        self.artefact_dir = artefact_dir

    def fit(self, model, optimiser: torch.optim.Optimizer, criterion, batch_size: int,
            number_of_epochs: int, save: bool, save_interval: int) -> float:
        
        p_bar = tqdm(range(1, number_of_epochs + 1), total=len(range(number_of_epochs)), ncols=100)
        epoch_accuracy = 0.0
        for epoch in p_bar:
            model.train()
            for batch_idx, (data, target) in enumerate(self.train_dataloader):
                data, target = data.to(self.device), target.to(self.device)
                optimiser.zero_grad()
                output = model(data)
                loss = criterion(output, target)
                loss.backward()
                optimiser.step()

                if batch_idx % 100 == 0:
                    tqdm.write(f"Train Epoch: {epoch} Batch " + 
                               f"[{batch_idx * len(data)}/{len(self.train_dataloader.dataset)} " +    # type: ignore
                               f"({100.0 * batch_idx / len(self.train_dataloader):.0f}%)] Loss: {loss.item():.4f}")

            model.eval()
            test_loss = 0
            correct = 0
            with torch.no_grad():
                for data, target in self.test_dataloader:
                    data, target = data.to(self.device), target.to(self.device)
                    output = model(data)
                    test_loss += criterion(output, target).item()
                    pred = output.max(1, keepdim=True)[1]
                    correct += pred.eq(target.view_as(pred)).sum().item()

            test_loss /= len(self.test_dataloader.dataset)    # type: ignore
            
            p_bar.set_description(f"Epoch {epoch}/{number_of_epochs}")
            epoch_accuracy = (correct / len(self.test_dataloader.dataset)) * 100    # type: ignore
            p_bar.set_postfix(loss=test_loss, accuracy=f"{epoch_accuracy:.2f}%")

            
            os.makedirs(self.artefact_dir, exist_ok=True)

            if save and epoch % save_interval == 0:
                torch.save(model.state_dict(), os.path.join(self.artefact_dir, f"model_epoch_{epoch}.pt"))
        return epoch_accuracy