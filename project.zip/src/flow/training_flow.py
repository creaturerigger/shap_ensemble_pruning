# src/flows/training_flow.py

import os
os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] = "1"

import logging
logging.getLogger("shap").setLevel(logging.ERROR)


from prefect import flow, task
from prefect.logging import get_run_logger
from src.trainer.CNN import CustomCNN
from src.trainer.trainer import Trainer
from src.image_extractor.image_feature_extractor import extract_and_save_features
from src.logger.logger import PostgresLogger
from src.ensemble_trainer.ensemble_trainer import CNNEnsembleTrainer

import torch
import torch.optim as optim
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
from shap import DeepExplainer
import numpy as np
from typing import List
import os
from tqdm import tqdm
import yaml
import random

@task
def get_dataloaders(dataset_name: str, batch_size: int=64) -> tuple:
    transform = transforms.ToTensor()

    if dataset_name == "mnist":
        train_ds = datasets.MNIST(root="MNIST", train=True, download=True, transform=transform)
        test_ds = datasets.MNIST(root="MNIST", train=False, download=True, transform=transform) 
        input_channels = 1
        num_classes = 10
    elif dataset_name == "cifar10":
        train_ds = datasets.CIFAR10(root="CIFAR10", train=True, download=True, transform=transform)
        test_ds = datasets.CIFAR10(root="CIFAR10", train=False, download=True, transform=transform)
        input_channels = 3
        num_classes = 10
    else:
        raise ValueError(f"Dataset '{dataset_name}' is not supported")
    
    train_loader = DataLoader(train_ds, batch_size, shuffle=True)
    test_loader = DataLoader(test_ds, batch_size=int((len(test_ds) / len(train_ds)) * batch_size))
    
    for x, _ in train_loader:
        _, c, h, w = x.shape
        image_size = (h, w)
        break
    
    return (
        train_loader,
        test_loader,
        input_channels,
        num_classes,
        image_size    # type: ignore
    )

@task
def train_model(train_loader, test_loader, input_channels, num_classes, image_size, epochs: int,
                dataset_name):
    logger = PostgresLogger()
    prefect_logger = get_run_logger()

    model_root_dir = f"model_artefacts/{dataset_name}"

    if logger.check_if_completed(dataset_name, step='train'):
        prefect_logger.info(f"🔁 Training already done for '{dataset_name}', skipping.")
        model = CustomCNN(input_channels, num_classes, image_size)
        model.load_state_dict(torch.load(f"{model_root_dir}/model_epoch_{epochs}.pt"))
        model.eval()
        return model
    model = CustomCNN(input_channels, num_classes, image_size)
    optimiser = optim.Adam(model.parameters(), lr=1e-3)
    criterion = nn.CrossEntropyLoss()
    trainer = Trainer(train_loader, test_loader, model_root_dir)
    final_test_acc = trainer.fit(model, optimiser, criterion, 64, epochs, True, 1)

    logger.log_run(
        dataset=dataset_name,
        step="train",
        status="completed",
        model_path=model_root_dir,
        accuracy=final_test_acc
    )

    return model

@task
def extract_features(model, dataloader, dataset_name: str, split: str='train'):
    logger = PostgresLogger()
    prefect_logger = get_run_logger()
    out_dir = f"extracted_features/{dataset_name}"
    feature_path = f"{out_dir}/{split}_features.npy"

    if logger.check_if_completed(dataset_name, f"extract_{split}"):
        prefect_logger.info(f"✅ Skipping feature extraction for {dataset_name} ({split})")
        return

    extract_and_save_features(model, dataloader, dataset_name, out_dir, split)

    logger.log_run(
        dataset=dataset_name,
        step=f"extract_{split}",
        status="completed",
        feature_path=feature_path
    )

@task
def apply_shap_and_save(model, dataloader, dataset_name: str, split: str = 'train'):
    import torch.nn as nn
    if torch.backends.mps.is_available():
        device = torch.device("mps")
    elif torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")

    model.to(device)
    model.eval()

    logger = PostgresLogger()
    prefect_logger = get_run_logger()

    def save_shap_and_inputs(shap_values, images, labels, out_dir, batch_idx):
        os.makedirs(out_dir, exist_ok=True)
        np.save(os.path.join(out_dir, f"images_batch{batch_idx}.npy"), images.cpu().numpy())
        np.save(os.path.join(out_dir, f"labels_batch{batch_idx}.npy"), labels.cpu().numpy())
        np.save(os.path.join(out_dir, f"shap_batch{batch_idx}.npy"), shap_values)

    out_dir = f"shap_values/{dataset_name}/{split}"
    os.makedirs(out_dir, exist_ok=True)

    if logger.check_if_completed(dataset_name, f"shap_full_{split}"):
        prefect_logger.info(f"✅ SHAP already completed for {dataset_name} ({split})")
        return

    background_data = next(iter(dataloader))[0][:5].to(device)
    explainer = DeepExplainer(model, background_data)

    total_batches = len(dataloader)
    shap_p_bar = tqdm(dataloader, desc=f"Computing SHAP ({split})")
    for batch_idx, (images, labels) in enumerate(shap_p_bar):
        images = images[:4].to(device)
        labels = labels[:4].to(device)

        shap_vals, _ = explainer.shap_values(images, ranked_outputs=1, check_additivity=False)

        
        shap_vals = np.squeeze(np.stack(shap_vals), axis=-1)    # type: ignore
    
        save_shap_and_inputs(shap_vals, images, labels, out_dir, batch_idx)

        if batch_idx % 5 == 0:
            shap_p_bar.set_description(f"✅ Processed batch {batch_idx+1}/{total_batches}")

    logger.log_run(
        dataset=dataset_name,
        step=f"shap_full_{split}",
        status="completed",
        feature_path=out_dir
    )


@task
def train_ensemble(dataset_name: str):
    logger = PostgresLogger()
    prefect_logger = get_run_logger()

    if logger.check_if_completed(dataset_name, step='ensemble'):
        prefect_logger.info(f"✅ Ensemble already completed for {dataset_name}")
        return

    with open("config/ensemble_config.yaml", "r") as f:
        ensemble_config = yaml.safe_load(f)

    ensemble_models = list(ensemble_config.keys())
    fixed_rand = random.Random(42)
    ensemble_models = fixed_rand.sample(ensemble_models, 100)
    pbar = tqdm(ensemble_models, desc="Training ensemble models")

    for model_id in pbar:
        trainer = CNNEnsembleTrainer(
            model_id=model_id,
            top_k_percentile=90,
            shap_dir="shap_values",
            dataset_name=dataset_name,
            early_stopping_patience=20
        )
        result = trainer.train()

        pbar.set_description(
            f"Model: {model_id} | Best Acc: {result['best_val_acc']:.4f} | Epochs: {result['epochs_trained']}"
        )

    logger.log_run(
        dataset=dataset_name,
        step="ensemble",
        status="completed",
        model_path="ensemble_models"
    )

@flow
def training_flow(dataset_name: str, num_epochs=5):
    train_loader, test_loader, input_channels, num_classes, image_size = get_dataloaders(dataset_name)
    model = train_model(train_loader, test_loader, input_channels, num_classes, image_size, num_epochs, dataset_name)
    apply_shap_and_save(model, train_loader, dataset_name)
    apply_shap_and_save(model, train_loader, dataset_name, split='test')
    train_ensemble(dataset_name)
